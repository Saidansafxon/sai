print("Afzalxonov Saidansaf")
print(54+53)
print("salom", end=" ")
print("hello")
